package com.cmriddles.thenewereconomy.api.account;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/** Stable identities for shared system accounts, independent of currency balances. */
public final class SystemAccountIds {
    public static final UUID VAULT_CHECKING = named("vault-checking");
    public static final UUID CONVERSION_RECEIPTS = named("conversion-receipts");
    public static final UUID CONVERSION_PAYOUTS = named("conversion-payouts");
    private static final Map<UUID, UUID> MIGRATIONS = Map.of(
            new UUID(0L, 1L), VAULT_CHECKING,
            new UUID(0L, 2L), CONVERSION_RECEIPTS,
            new UUID(0L, 3L), CONVERSION_PAYOUTS);

    private SystemAccountIds() {}

    /** Exact reserved identities migrated by SQL bootstrap; custom account IDs stay unchanged. */
    public static Map<UUID, UUID> migrations() { return MIGRATIONS; }

    /** Resolve a reserved historical identity at configuration or historical-evidence boundaries. */
    public static UUID canonical(UUID accountId) {
        Objects.requireNonNull(accountId, "accountId");
        return MIGRATIONS.getOrDefault(accountId, accountId);
    }

    private static UUID named(String role) {
        return UUID.nameUUIDFromBytes(("tne:system:" + role).getBytes(StandardCharsets.UTF_8));
    }
}
