package com.cmriddles.thenewereconomy.api.currency;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.Duration;
import java.util.Objects;

/** Exact whole-second currency conversion; never uses floating point. */
public final class TimeAmount {
    private TimeAmount() {}
    public static BigDecimal seconds(Duration duration) {
        Objects.requireNonNull(duration, "duration");
        if (duration.getNano() != 0) throw new IllegalArgumentException("Time currency uses whole seconds");
        return BigDecimal.valueOf(duration.getSeconds());
    }
    public static Duration duration(BigDecimal seconds) {
        return Duration.ofSeconds(Objects.requireNonNull(seconds, "seconds").longValueExact());
    }
    public static String format(BigDecimal seconds) {
        BigInteger value = Objects.requireNonNull(seconds, "seconds").toBigIntegerExact();
        String sign = value.signum() < 0 ? "-" : "";
        BigInteger[] days = value.abs().divideAndRemainder(BigInteger.valueOf(86400));
        long remainder = days[1].longValueExact();
        return sign + days[0] + "d " + (remainder / 3600) + "h "
                + ((remainder % 3600) / 60) + "m " + (remainder % 60) + "s";
    }
}
