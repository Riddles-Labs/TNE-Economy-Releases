package com.cmriddles.thenewereconomy.api.checking;

import com.cmriddles.thenewereconomy.api.account.AccountRef;
import com.cmriddles.thenewereconomy.api.economy.TransactionReceipt;
import com.cmriddles.thenewereconomy.api.result.Result;
import java.math.BigDecimal;
import java.util.concurrent.CompletionStage;

/** Owner-authorized payouts from funded TNE Checking. Never creates currency or uses Vault funds. */
public interface ServerCheckingService {
    /** Stable account reference for this currency; lookup does not grant spending permission. */
    AccountRef account(String currency);
    /** Pays an existing destination, recording the plugin and reason. Reuse the key only for retries of this payout. */
    CompletionStage<Result<TransactionReceipt>> pay(AccountRef destination, String currency,
            BigDecimal amount, String reason, String idempotencyKey);
}
